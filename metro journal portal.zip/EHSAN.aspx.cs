﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EHSAN : FormBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        NotifyShow("this is test notify", NotifyType.alert);
    }
}