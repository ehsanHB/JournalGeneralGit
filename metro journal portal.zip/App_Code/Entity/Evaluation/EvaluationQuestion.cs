﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EvaluationQuestion
/// </summary>

public abstract class EvaluationQuestion
{
    #region Attribute
    int _id;
    string _title;
    
    EvaluationAnswer _selectedoption;
    string _selectedcomment;
    private PersianDateTime _date;
    EvaluationQuestionType _type;
   // PaperProcedures _procedur;
    User_cls _createby;
    #endregion

    #region Property
    public int ID
    {
        get { return _id; }
        set { _id = value; }
    }
    /// <summary>
    /// matne soal
    /// </summary>
    public string Title
    {
        get { return _title; }
        set { _title = value; }
    }
    public EvaluationQuestionType Type
    {
        get { return _type; }
        set { _type = value; }
    }
    //public PaperProcedures Procedur
    //{
    //    get { return _procedur; }
    //    set { _procedur = value; }
    //}
    public User_cls Createby
    {
        get { return _createby; }
        set { _createby = value; }
    }
    public PersianDateTime Date
    {
        get { return _date; }
        set { _date = value; }
    }
    #endregion
    

}
public class EvaluationQuestionType
{
    int _id;
    string _title;

    public string Title
    {
        get { return _title; }
       
    }
    public int ID
    {
        get { return _id; }
        set
        {
            _title = EvaluationQuestionType.Convet(value);
            _id = value;
        }
    }

    public EvaluationQuestionType(int id)
    {
        this.ID = id;
    }
    #region Static member
    /// <summary>
    /// soal chand gozine ee 
    /// </summary>
    public static int Options
    {
        get { return 1; }
    }
    /// <summary>
    /// soale tashrihi
    /// </summary>
    public static int Comment
    {
        get { return 2; }
    }
    /// <summary>
    /// soalee ke bayad nomre dahad
    /// </summary>
    public static int Numeric
    {
        get { return 3; }
    }
    public static string Convet(int id)
    {
        switch (id)
        {
            case 1:
                return "Option";
            case 2:
                return "Comment";
            case 3:
                return "Numeric";
            default:
                throw new Exception("invalid EvaluationQuestionType id");
        }
    }
    #endregion
}