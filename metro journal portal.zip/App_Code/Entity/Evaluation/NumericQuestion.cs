﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// soalati ke bayad nomre dehi shavad dar in object gharar migirad
/// </summary>
public class NumericQuestion:EvaluationQuestion
{
    int _min;
    int _max;
    int _score;

    
    /// <summary>
    /// hade aksar nomre ee ke mitavanad dahad
    /// </summary>
    public int Max
    {
        get { return _max; }
        set { _max = value; }
    }
    /// <summary>
    /// hadeaghal nomre
    /// </summary>
    public int Min
    {
        get { return _min; }
        set { _min = value; }
    }
    /// <summary>
    /// emtiazi karbar dar pasokh be in soal midahad
    /// </summary>
    public int Score
    {
        get { return _score; }
        set { _score = value; }
    }
	public NumericQuestion()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}