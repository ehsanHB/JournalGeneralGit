﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// yek class baraye zakhire har form arzyabi
/// </summary>
public class EvaluationForm
{
    List<EvaluationQuestion> _questions;

    /// <summary>
    /// neveshtan va khondan soalat mojod dar in form
    /// </summary>
    /// <param name="index"></param>
    /// <returns></returns>
    public EvaluationQuestion this[int index]
    {
        get { return _questions[index]; }
        set { _questions[index] = value; }
    }
	public EvaluationForm()
	{
	
        this._questions = new List<EvaluationQuestion>();
	}
}