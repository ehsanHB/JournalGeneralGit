﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// objecti ke soalat chand gozine ee dar un gharar migirad
/// </summary>
public class Multiple_ChoiceQuestions:EvaluationQuestion
{

    List<AnswerOption> _options;

    /// <summary>
    /// gereftan ya neveshtan list gozine haye in soal
    /// </summary>
    /// <param name="index"></param>
    /// <returns></returns>
    public AnswerOption this[int index]
    {
        get
        {
            return _options[index];
        }
        set
        {
            _options[index] = value;
        }
    }
	public Multiple_ChoiceQuestions()
	{
        _options = new List<AnswerOption>();
        
	}
    
}
public class AnswerOption
{
    int _id;
    string _title;
    bool _isSelected=false;


    /// <summary>
    /// inke aya entekhab shode ya kheyr
    /// </summary>
    public bool IsSelected
    {
        get { return _isSelected; }
        set { _isSelected = value; }
    }
    /// <summary>
    /// unvane gozine chist
    /// </summary>
    public string Title
    {
        get { return _title; }
        set { _title = value; }
    }
    public int ID
    {
        get { return _id; }
        set { _id = value; }
    }
}