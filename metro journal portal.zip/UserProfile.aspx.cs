﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserProfile : FormBase
{
    public static string PageAddress
    {
        get { return ServerDirectory.Host + "/UserProfile.aspx"; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        UserVerification();
        FillInfo();
    }

    public void FillInfo()
    {
        UserInfoMan_Business userInfoMan = new UserInfoMan_Business();
        FullUser fulluser = userInfoMan.GetClientFullUserInfo();
        lblName.Text = fulluser.User.Fname;
        lblLastName.Text = fulluser.User.Lname;
        lblEmail.Text = fulluser.User.Email;
        lblAffiliations.Text = fulluser.User.Affiliations;
        lblPhoneNumber.Text = fulluser.User.Phone;
        lblFax.Text = fulluser.User.Fax;
        lblFieldsOfInterest.Text = fulluser.User.Fields;
        lblNationalCode.Text = fulluser.User.Melli;
        lblEducation.Text = fulluser.User.Education;
        lblbBirthDate.Text = fulluser.User.Birthdate.Datetime.ToString("yyyy.MM.dd");
        lblGender.Text = fulluser.User.Sex.Title;

    }

}