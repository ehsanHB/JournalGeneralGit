﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SubmitOnline_Step4 : FormBase
{
    public static string PageAddress
    {
        get { return ServerDirectory.Paper + "/SubmitOnline_Step4.aspx"; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        AuthorVerification();
        if (Session[RequestMSG.SubmitOnline] == null)
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline.aspx");
    }

    protected void btnFinish_Click(object sender, EventArgs e)
    {
        string[] names = hfFirstName.Value.Split(',');
        string[] lastnames = hflastName.Value.Split(',');
        string[] mails = hfEmail.Value.Split(',');
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        List<User_cls> referees = new List<User_cls>();
        for (int i = 0; i < names.Length - 1; i++)
        {
            referees.Add(new User_cls() { Fname = names[i], Lname = lastnames[i], Email = mails[i] });
        }
        Paper paper = (Paper)Session[RequestMSG.SubmitOnline];
        DBmessage dbm = paperInfoMan.RegisterPaper_Step4(referees, paper.ID);
        if (dbm.Type == DBMessageType.Sucsess)
        {
            Session.Remove(RequestMSG.SubmitOnline);
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline_Step4.aspx");
        }
        else
        ShowNotify(dbm);
    }
}