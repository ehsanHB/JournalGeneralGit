﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Paper_PaperListAuthor : FormBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        AuthorVerification();
        FillGridView();
    }

    public void FillGridView()
    {
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        PaperReport paperReport = paperInfoMan.GetPaperListForAuther();
        gvPapers.DataSource = paperReport.Papers;
        gvPapers.DataBind();
    }

    public string DateTimeInString(DateTime dt)
    {
        return dt.ToString("yyyy.MM.dd");
    }

    public string PaperStatusInString(int statusID)
    {
        return PaperStatus.Convert(statusID);
    }

    protected void lnkbShow_Click(object sender, EventArgs e)
    {
        int id = int.Parse(((LinkButton)sender).CommandArgument);
        Response.Redirect(ServerDirectory.Paper + "/PaperInformation.aspx?" + RequestMSG.ID + "=" + id);
    }
    public bool ContinueToolVisible(object obj)
    {
        PaperInfo paperInfo = (PaperInfo)obj;
        return paperInfo.IsNew;
    }
    protected void lnkbContinue_Click(object sender, EventArgs e)
    {
        string[] IDs = (((LinkButton)sender).CommandArgument).ToString().Split(',');
        int statusID = int.Parse(IDs[0]);
        int paperID = int.Parse(IDs[1]);
        if(statusID == PaperStatus.Preparing_step1)
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline_Step2.aspx?" + RequestMSG.ID + "=" + paperID);
        if (statusID == PaperStatus.Preparing_step2)
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline_Step3.aspx?" + RequestMSG.ID + "=" + paperID);
        if (statusID == PaperStatus.Preparing_step3)
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline_Step4.aspx?" + RequestMSG.ID + "=" + paperID);
    }
}