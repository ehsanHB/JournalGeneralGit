﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PaperInformation : FormBase
{
    public static string PageAddress
    {
        get { return ServerDirectory.Paper + "/PaperInformation.aspx"; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        NotifyShow("", NotifyType.warning);

        UserVerification();
        if (!IsPostBack)
        {
            FillRefereesInfo();
            FillEditorsInfo();
        }
        FillInfo();
    }
    public PaperInfo info;
    public void FillInfo()
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        txtbExpDate.Text = DateTime.Now.Add(SysProperty.ExpirationForSelectReferee).ToString("yyyy.MM.dd");
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        info = paperInfoMan.GetPaperInfo(paperID);
        if (info != null)
        {
            btnRefereesSelection.Visible = info.CanBeSelectRefrees;
            btnEditorSelection.Visible = info.CanBeSelectEditorByChefEditor;
            btnAcceptByChefEditor.Visible = info.CanBeAcceptByChefEditor;
            btnRejectByChefEditor.Visible = info.CanBeRejectByChefEditor;
            btnAcceptArbitration.Visible = info.CanBeAcceptByReferee;
            btnRejectArbitrationArticle.Visible = info.CanBeRejectByReferee;
            lblTitle.Text = info.Title;
            lblAbstract.Text = info.Abstracts;
            lblFieldPaper.Text = info.Feilds;
            lblKeyWord.Text = info.Keyword;
            //------Fill GridView --------//
            gvAuthors.DataSource = info.Authors;
            DataBind();
            //-----------Files------------//

        }

    }
    protected void btnAcceptByChefEditor_Click(object sender, EventArgs e)
    {

        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.AcceptByChefEditor(paperID);
        ShowNotify(dbm);
    }

    protected void btnRejectByChefEditor_Click(object sender, EventArgs e)
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.RejectByChefEditor(paperID);
        ShowNotify(dbm);
    }
    private void FillRefereesInfo()
    {
        UserInfoMan_Business userInfoMan = new UserInfoMan_Business();
        List<User_cls> users = userInfoMan.GetRefereesList();
        if (users != null)
            for (int i = 0; i < users.Count; i++)
            {
                ddlReferee.Items.Add(new ListItem(users[i].Email, users[i].UserID.ToString()));
            }
    }
    private void FillEditorsInfo()
    {
        UserInfoMan_Business userInfoMan = new UserInfoMan_Business();
        List<User_cls> users = userInfoMan.GetEditorList();
        if (users != null)
            for (int i = 0; i < users.Count; i++)
            {
                ddlEditors.Items.Add(new ListItem(users[i].FullName, users[i].UserID.ToString()));
            }
    }
    protected void btnSelectReferee_Click(object sender, EventArgs e)
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.SelectRefree(paperID, hfRefereeMail.Value, new PersianDateTime(Convert.ToDateTime(txtbExpDate.Text)));
        ShowNotify(dbm);
    }


    protected void btnAcceptArbitration_Click(object sender, EventArgs e)
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.AcceptByReferee(paperID);
        FillInfo();
        ShowNotify(dbm);
    }

    protected void btnRejectArbitrationArticle_Click(object sender, EventArgs e)
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.RejectByReferee(paperID);
        FillInfo();
        ShowNotify(dbm);
    }

    protected void btnSelectEditor_Click(object sender, EventArgs e)
    {
        int paperID = Convert.ToInt32(Request[RequestMSG.ID]);
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        DBmessage dbm = paperInfoMan.SelectEditor(paperID, Convert.ToInt32(ddlEditors.SelectedValue));
        FillInfo();
        ShowNotify(dbm);
    }
}



