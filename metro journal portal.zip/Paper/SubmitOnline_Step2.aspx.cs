﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SubmitOnline_Step2 : FormBase
{
    public static string PageAddress
    {
        get { return ServerDirectory.Paper + "/SubmitOnline_Step2.aspx"; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        AuthorVerification();
        if (Session[RequestMSG.SubmitOnline] == null)
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline.aspx");

    }
    protected void btnStep3_Click(object sender, EventArgs e)
    {
        PaperInfoMan_Business paperInfoMan = new PaperInfoMan_Business();
        List<PaperWriter> paperWriters = new List<PaperWriter>();
        string[] names = hfFirstName.Value.Split(',');
        string[] lastnames = hflastName.Value.Split(',');
        string[] incharge = hfIncharge.Value.Split(',');
        for (int i = 0; i < names.Length - 1; i++)
        {

            paperWriters.Add(new PaperWriter()
            {
                Fname = names[i],
                Lname = lastnames[i],
                Responsibility = new PaperWriterResponsibility(Resposibility(incharge[i]))
            });
        }
        Paper paper = (Paper)Session[RequestMSG.SubmitOnline];
        DBmessage dbm = paperInfoMan.RegisterPaper_Step2(paperWriters,paper.ID);
        if (dbm.Type == DBMessageType.Sucsess)
        {
            Response.Redirect(ServerDirectory.Paper + "/SubmitOnline_Step3.aspx");
        }
        else
            ShowNotify(dbm);
    }
    public int Resposibility(string status)
    {
        if (status == "On")
        {
            return PaperWriterResponsibility.Encharge;
        }
        else
        {
            return PaperWriterResponsibility.Normal;
        }
    }
}